import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"
import HomePage from './Page/HomePage';

const App = () => {
  return (
    <>
      <div className="App">
        <HomePage />
      </div>
      {/* FOOTER */}
      <div class='w-100 bg mt5'>
      </div>
    </>
  );
}

export default App;
